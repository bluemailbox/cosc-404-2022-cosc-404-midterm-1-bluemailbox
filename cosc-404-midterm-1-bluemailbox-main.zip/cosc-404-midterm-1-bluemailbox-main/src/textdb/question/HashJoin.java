package textdb.question;

import java.io.IOException;
import java.util.HashMap;

import textdb.functions.Expression;
import textdb.functions.ExtractAttribute;
import textdb.operators.Operator;
import textdb.operators.Projection;
import textdb.operators.Selection;
import textdb.operators.TextFileScan;
import textdb.predicates.SelectionPredicate;
import textdb.relation.Attribute;
import textdb.relation.Relation;
import textdb.relation.Tuple;
import textdb.predicates.ConstantSelectionPredicate;
import textdb.predicates.Less;

/**
 * Implements in-memory hash join.
 * 
 * Notes:
 * 1) Left input is smaller build input. Right input is larger probe input.
 * 2) Uses a HashMap to quickly find tuples based on keys.
 * 3) Duplicate keys on the build input are NOT supported (due to using a HashMap). This means each probe tuple can only match at most one build tuple.
 * 4) Only supports one attribute equi-joins on integer keys.
 */
public class HashJoin extends Operator
{
	// Iterator state variables
	private int buildTupleIdx;					// Index of join attribute in build table
	private int probeTupleIdx;					// Index of join attribute in probe table
	public HashMap<Integer, Tuple> hashTable;	// Hash table to put tuples of build relation into


	public HashJoin(Operator []in, int buildTupleIdx, int probeTupleIdx)
	{	super(in, 10, 10000);
		this.buildTupleIdx = buildTupleIdx;
		this.probeTupleIdx = probeTupleIdx;

		// Create output relation - keep all attributes of both tuples
		Relation out = new Relation(input[0].getOutputRelation());
		out.mergeRelation(input[1].getOutputRelation());
		setOutputRelation(out);
	}

	public void init() throws IOException
	{
		// TODO: Initialize inputs
		input[0].init();
		input[1].init();
		
		// TODO: Create a HashMap object
		hashTable = new HashMap<Integer, Tuple>();

		// TODO: Read all tuples from left input (input[0]) and put in hash table. Use getInt() to get value of the tuple at buildTupleIdx
		Tuple leftTuple;
		while((leftTuple = input[0].next()) != null)
		hashTable.add(leftTuple);
		hashTable.getInt(buildTupleIdx);
		input[0].close();		
		// TODO: Close input[0]
	
	}


	public Tuple next() throws IOException
	{
		// TODO: Read a probe tuple. Check for matches in HashMap.
		tuple rightTuple;
		while((rightTuple = input[1].next()) != null) {
			int index = righTuple.getInt(buildTupleIdx);
			if(index < hashTable.size() && index >= 0)
			return outputJoinTuple(hashTable.get(index), rightTuple);
		}
		// TODO: If have a match, return outputJoinTuple(matchTuple, probeTuple);
		
		return null;
	}

	public void close() throws IOException
	{	super.close();
	}

	private Tuple outputJoinTuple(Tuple left, Tuple right)
	{	Tuple t = new Tuple(left, right, getOutputRelation());
		incrementTuplesOutput();
		return t;
	}	

	/*
	NOTE: Main method is only if you want to test separate from JUnit test. It is JUnit tests you must run.
	*/
	public static void main(String []argv) throws Exception
	{
		// Use nation table as build table
		Attribute []nAttr = new Attribute[4];
		nAttr[0] = new Attribute("n_nationkey",Attribute.TYPE_INT,0);
		nAttr[1] = new Attribute("n_name",Attribute.TYPE_STRING,25);
		nAttr[2] = new Attribute("n_regionkey",Attribute.TYPE_INT,0);
		nAttr[3] = new Attribute("n_comment",Attribute.TYPE_STRING,152);			
		Relation nation = new Relation(nAttr, "nation", "bin/data/nation.txt");

		Attribute []attrs = new Attribute[8];
		attrs[0] = new Attribute("c_custkey",Attribute.TYPE_INT,0);
		attrs[1] = new Attribute("c_name",Attribute.TYPE_STRING,25);
		attrs[2] = new Attribute("c_address",Attribute.TYPE_STRING,75);
		attrs[3] = new Attribute("c_nationkey",Attribute.TYPE_INT,0);
		attrs[4] = new Attribute("c_phone",Attribute.TYPE_STRING,15);
		attrs[5] = new Attribute("c_acctbal",Attribute.TYPE_DOUBLE,0);
		attrs[6] = new Attribute("c_mktsegment",Attribute.TYPE_STRING,20);
		attrs[7] = new Attribute("c_comment",Attribute.TYPE_STRING,200);				
		Relation customer = new Relation(attrs, "customer", "bin/data/customer.txt");

		/* Table scan operator */
		TextFileScan nscan = new TextFileScan("bin/data/nation.txt", nation);
		TextFileScan cscan = new TextFileScan("bin/data/customer.txt", customer);

		SelectionPredicate pred2 = new ConstantSelectionPredicate(0, 20, new Less());
		Selection csel = new Selection(cscan, pred2);
		
		HashJoin hj = new HashJoin(new Operator[]{nscan, csel}, 0, 3);

		Expression[] expr = new Expression[5];
		expr[0] = new ExtractAttribute(0);  
		expr[1] = new ExtractAttribute(1);  
		expr[2] = new ExtractAttribute(4);        
		expr[3] = new ExtractAttribute(5);        
		expr[4] = new ExtractAttribute(7);        

/*
		SelectionPredicate pred = new ConstantSelectionPredicate(0, 5, new Less());
		Selection nsel = new Selection(nscan, pred);

		SelectionPredicate pred2 = new ConstantSelectionPredicate(0, 1000, new Less());
		Selection csel = new Selection(cscan, pred2);
		
		HashJoin hj = new HashJoin(new Operator[]{csel, nsel}, 0, 0);		

		Expression[] expr = new Expression[4];
		expr[0] = new ExtractAttribute(0);  
		expr[1] = new ExtractAttribute(1);  
		expr[2] = new ExtractAttribute(8);        
		expr[3] = new ExtractAttribute(9);        		      
*/
		System.out.println("Generating query output.");

		Projection proj = new Projection(hj, expr);

		Tuple t;
		Operator op = proj;
		op.init();
		int count = 0;
		while ( (t = op.next()) != null)
		{
			System.out.println(t);
			count++;			
		}
		op.close();

		System.out.println("Query complete. Rows: "+count);
	}
}

