[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10313494&assignment_repo_type=AssignmentRepo)
# COSC 404 Midterm 1

## Question 1

Edit `HashJoin.java` to implement an in-memory, one-pass hash join that:

- Buffers left input (`input[0]`) in an in-memory hash table (use: HashMap). We will assume no duplicates in the hash table.

- Probes with right input (`input[1]`) to generate matches. 

Tests are `TestHashJoin.java`.

## Question 2

Edit `QueryTree.java` to implement two query plans:

### Plan #1 (2 marks) for:

```
SELECT n_nationkey, n_name, n_regionkey FROM nation WHERE n_nationkey < 10 ORDER BY n_name DESC
```

### Plan #2 (3 marks) for:

```
SELECT r_regionkey, r_name, c_nationkey, c_custkey, c_name, c_acctbal 
FROM region JOIN customer ON r_regionkey=c_nationkey
WHERE c_acctbal > 9900 
ORDER BY c_acctbal DESC
```

Tests are `TestQueryTree.java`.

**When done, commit/push your repository. Submit the URL of the repository on Canvas.**
